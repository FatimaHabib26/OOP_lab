﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportManagementSystem1.Repositories
    {
        public class BusRepository
        {
            private readonly string filePath = "buses.txt";

            public List<Bus> GetAllBusesFromFile()
            {
                List<Bus> buses = new List<Bus>();
                if (File.Exists(filePath))
                {
                    using (StreamReader reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] parts = line.Split(',');
                            if (parts.Length == 5)
                            {
                                int bNo = int.Parse(parts[0]);
                                string rt = parts[1];
                                string tm = parts[2];
                                int tSeats = int.Parse(parts[3]);
                                int bSeats = int.Parse(parts[4]);

                                Bus bus = new Bus(bNo, rt, tm, tSeats, bSeats);
                                buses.Add(bus);
                            }
                        }
                    }
                }
                else
                {
                    buses.Add(new Bus(101, "Lahore-Islamabad", "08:00AM", 40, 0));
                    buses.Add(new Bus(102, "Karachi-Lahore", "02:00PM", 35, 0));
                    buses.Add(new Bus(103, "Peshawar-Islamabad", "06:00PM", 45, 0));
                    SaveAllBusesToFile(buses);
                }
                return buses;
            }

            public void SaveAllBusesToFile(List<Bus> buses)
            {
                using (StreamWriter writer = new StreamWriter(filePath, false))
                {
                    foreach (var bus in buses)
                    {
                        writer.WriteLine(bus.ToString());
                    }
                }
            }
        }
    }
 
