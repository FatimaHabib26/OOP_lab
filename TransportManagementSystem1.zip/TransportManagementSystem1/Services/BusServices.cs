﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransportManagementSystem1.Services
{
    namespace TransportManagementSystem1.Services
    {
        public class BusService
        {
            private BusRepository repository;

            public BusService()
            {
                repository = new BusRepository();
            }

            public List<Bus> GetAllBuses()
            {
                return repository.GetAllBusesFromFile();
            }

            public bool AddBus(int busNo, string route, string time, int totalSeats)
            {
                List<Bus> buses = repository.GetAllBusesFromFile();
                foreach (var b in buses)
                {
                    if (b.GetBusNo() == busNo) return false;
                }

                Bus newBus = new Bus(busNo, route, time, totalSeats, 0);
                buses.Add(newBus);
                repository.SaveAllBusesToFile(buses);
                return true;
            }

            public Bus SearchBus(int busNo)
            {
                List<Bus> buses = repository.GetAllBusesFromFile();
                foreach (var b in buses)
                {
                    if (b.GetBusNo() == busNo) return b;
                }
                return null;
            }

            public bool UpdateBus(int busNo, string newRoute, string newTime, int newTotalSeats)
            {
                List<Bus> buses = repository.GetAllBusesFromFile();
                bool found = false;
                foreach (var b in buses)
                {
                    if (b.GetBusNo() == busNo)
                    {
                        b.SetRoute(newRoute);
                        b.SetTime(newTime);
                        b.SetTotalSeats(newTotalSeats);
                        found = true;
                        break;
                    }
                }

                if (found)
                {
                    repository.SaveAllBusesToFile(buses);
                    return true;
                }
                return false;
            }

            public bool DeleteBus(int busNo)
            {
                List<Bus> buses = repository.GetAllBusesFromFile();
                Bus busToRemove = null;
                foreach (var b in buses)
                {
                    if (b.GetBusNo() == busNo)
                    {
                        busToRemove = b;
                        break;
                    }
                }

                if (busToRemove != null)
                {
                    buses.Remove(busToRemove);
                    repository.SaveAllBusesToFile(buses);
                    return true;
                }
                return false;
            }

            public bool BookSeat(int busNo, string passengerName)
            {
                List<Bus> buses = repository.GetAllBusesFromFile();
                bool success = false;
                foreach (var b in buses)
                {
                    if (b.GetBusNo() == busNo)
                    {
                        if (b.GetAvailableSeats() > 0)
                        {
                            b.AddBooking(new Booking(passengerName, DateTime.Now.ToString("yyyy-MM-dd")));
                            success = true;
                        }
                        break;
                    }
                }

                if (success)
                {
                    repository.SaveAllBusesToFile(buses);
                    return true;
                }
                return false;
            }

            public bool CancelBooking(int busNo)
            {
                List<Bus> buses = repository.GetAllBusesFromFile();
                bool success = false;
                foreach (var b in buses)
                {
                    if (b.GetBusNo() == busNo)
                    {
                        b.RemoveBooking();
                        success = true;
                        break;
                    }
                }

                if (success)
                {
                    repository.SaveAllBusesToFile(buses);
                    return true;
                }
                return false;
            }
        }
    }
}
    
