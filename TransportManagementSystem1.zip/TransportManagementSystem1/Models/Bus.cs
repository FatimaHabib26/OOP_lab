﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace TransportManagementSystem1.Models
    {
        public class Booking
        {
            private string passengerName;
            private string bookingDate;

            public Booking(string passengerName, string bookingDate)
            {
                this.passengerName = passengerName;
                this.bookingDate = bookingDate;
            }

            public string GetPassengerName() { return passengerName; }
            public string GetBookingDate() { return bookingDate; }
        }
    public class Bus
        {
            private int busNo;
            private string route;
            private string time;
            private int totalSeats;
            private int bookedSeats;
            private List<Booking> bookings;
            private static string agencyName = "Daewoo Express & Transport";

            public Bus()
            {
                busNo = 0;
                route = "";
                time = "";
                totalSeats = 0;
                bookedSeats = 0;
                bookings = new List<Booking>();
            }

            public Bus(int busNo, string route, string time, int totalSeats, int bookedSeats)
            {
                SetBusNo(busNo);
                SetRoute(route);
                SetTime(time);
                SetTotalSeats(totalSeats);
                this.bookedSeats = bookedSeats;
                bookings = new List<Booking>();
            }

            public static string GetAgencyName() { return agencyName; }

            public int GetBusNo() { return busNo; }
            public void SetBusNo(int busNo) { if (busNo > 0) this.busNo = busNo; }

            public string GetRoute() { return route; }
            public void SetRoute(string route) { if (!string.IsNullOrEmpty(route)) this.route = route; }

            public string GetTime() { return time; }
            public void SetTime(string time) { if (!string.IsNullOrEmpty(time)) this.time = time; }

            public int GetTotalSeats() { return totalSeats; }
            public void SetTotalSeats(int totalSeats) { if (totalSeats > 0) this.totalSeats = totalSeats; }

            public int GetBookedSeats() { return bookedSeats; }
            public List<Booking> GetBookings() { return bookings; }

            public int GetAvailableSeats() { return totalSeats - bookedSeats; }

            public void AddBooking(Booking booking)
            {
                if (bookedSeats < totalSeats)
                {
                    bookings.Add(booking);
                    bookedSeats++;
                }
            }

            public void RemoveBooking()
            {
                if (bookedSeats > 0 && bookings.Count > 0)
                {
                    bookings.RemoveAt(bookings.Count - 1);
                    bookedSeats--;
                }
            }

            public override string ToString()
            {
                return $"{busNo},{route},{time},{totalSeats},{bookedSeats}";
            }
        }
    }
   
